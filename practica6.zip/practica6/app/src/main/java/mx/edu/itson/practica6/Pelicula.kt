package mx.edu.itson.practica6

data class Pelicula(var titulo:String,
                    var image:Int,
                    var header:Int,
                    var sinopsis:String)
